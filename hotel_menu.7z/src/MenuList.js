import "./MenuList.css";

export default function MenuList(props) {
  console.log(props.data);
  return (
    <div className="cards">
      {props.data
        ? props.data.map((val) => {
            return (
              <div className="card-item">
                <p>{val.foodname}</p>
              </div>
            );
          })
        : ""}
    </div>
  );
}
