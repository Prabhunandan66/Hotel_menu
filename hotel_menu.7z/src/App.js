import logo from "./logo.svg";
import "./App.css";
import Menu from "./Menu";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <input type="text" placeholder="Q Search..."></input>
      </header>
      <Menu />
      <div className="footer">
        <button>ALL UNAVAILABLE</button>
        <button>ALL AVAILABLE</button>
        <button>APPLY</button>
      </div>
    </div>
  );
}

export default App;
